<?php
$DB_ADDR= "localhost";
$DB_USER = "han38";
$DBPW = "hdm1212*";
$DB_NAME = "han38";



$db = mysqli_connect( $DB_ADDR, $DB_USER, $DBPW, $DB_NAME);

if ( mysqli_connect_errno() )
{
echo "DB ���ῡ �����߽��ϴ� " . mysqli_connect_error();
}

if($db) {
         echo "DB Connect Successful";
}  else  {

          echo "DB Connect Fail:";
}

?>