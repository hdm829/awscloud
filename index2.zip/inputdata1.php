<?php
$kname =  $_POST['kname']; 
$ename =  $_POST['ename'];
$email =  $_POST['email'];
$pword =  $_POST['pword'];


if(isset($_POST['q0101'])){
    $q0101 = $_POST['q0101'];
}
 
if(isset($_POST['q0501'])){
    $q0501 = $_POST['q0501'];
}

if(isset($_POST['q0901'])){
    $q0901 = $_POST['q0901'];
}

if(isset($_POST['q1301'])){
    $q1301 = $_POST['q1301'];
}

if(isset($_POST['q1701'])){
    $q1701 = $_POST['q1701'];
}

if(isset($_POST['q2101'])){
    $q2101 = $_POST['q2101'];
}


if(isset($_POST['q2501'])){
    $q2501 = $_POST['q2501'];
}


if(isset($_POST['q2901'])){
    $q2901 = $_POST['q2901'];
}

if(isset($_POST['q3301'])){
    $q3301 = $_POST['q3301'];
}


if(isset($_POST['q3701'])){
    $q3701 = $_POST['q3701'];
}

if(isset($_POST['q0102'])){
    $q0102 = $_POST['q0102'];
}


if(isset($_POST['q0502'])){
    $q0502 = $_POST['q0502'];
}


if(isset($_POST['q0902'])){
    $q0902 = $_POST['q0902'];
}

if(isset($_POST['q1302'])){
    $q1302 = $_POST['q1302'];
}

if(isset($_POST['q1702'])){
    $q1702 = $_POST['q1702'];
}

if(isset($_POST['q2102'])){
    $q2102 = $_POST['q2102'];
}

if(isset($_POST['q2502'])){
    $q2502 = $_POST['q2502'];
}

if(isset($_POST['q2902'])){
    $q2902 = $_POST['q2902'];
}

if(isset($_POST['q3302'])){
    $q3302 = $_POST['q3302'];
}

if(isset($_POST['q3702'])){
    $q3702 = $_POST['q3702'];
}


if(isset($_POST['q0201'])){
    $q0201 = $_POST['q0201'];
}

if(isset($_POST['q0601'])){
    $q0601 = $_POST['q0601'];
}

if(isset($_POST['q1001'])){
    $q1001 = $_POST['q1001'];
}

if(isset($_POST['q1401'])){
    $q1401 = $_POST['q1401'];
}

if(isset($_POST['q1801'])){
    $q1801 = $_POST['q1801'];
}

if(isset($_POST['q2201'])){
    $q2201 = $_POST['q2201'];
}

if(isset($_POST['q2601'])){
    $q2601 = $_POST['q2601'];
}

if(isset($_POST['q3001'])){
    $q3001 = $_POST['q3001'];
}

if(isset($_POST['q3401'])){
    $q3401 = $_POST['q3401'];
}


if(isset($_POST['q3801'])){
    $q3801 = $_POST['q3801'];
}

if(isset($_POST['q0202'])){
    $q0202 = $_POST['q0202'];
}

if(isset($_POST['q0602'])){
    $q0602 = $_POST['q0602'];
}

if(isset($_POST['q1002'])){
    $q1002 = $_POST['q1002'];
}

if(isset($_POST['q1402'])){
    $q1402 = $_POST['q1402'];
}

if(isset($_POST['q1802'])){
    $q1802 = $_POST['q1802'];
}

if(isset($_POST['q2202'])){
    $q2202 = $_POST['q2202'];
}

if(isset($_POST['q2602'])){
    $q2602 = $_POST['q2602'];
}

if(isset($_POST['q3002'])){
    $q3002 = $_POST['q3002'];
}   

if(isset($_POST['q3402'])){
    $q3402 = $_POST['q3402'];
}   
 
if(isset($_POST['q3802'])){
    $q3802 = $_POST['q3802'];
}   

if(isset($_POST['q0301'])){
    $q0301 = $_POST['q0301'];
}   

if(isset($_POST['q0701'])){
    $q0701 = $_POST['q0701'];
}   

if(isset($_POST['q1101'])){
    $q1101 = $_POST['q1101'];
}  

if(isset($_POST['q1501'])){
    $q1501 = $_POST['q1501'];
}  

if(isset($_POST['q1901'])){
    $q1901 = $_POST['q1901'];
}  

if(isset($_POST['q2301'])){
    $q2301 = $_POST['q2301'];
}

if(isset($_POST['q2701'])){
    $q2701= $_POST['q2701'];
}

if(isset($_POST['q3101'])){
    $q3101= $_POST['q3101'];
}

if(isset($_POST['q3501'])){
    $q3501= $_POST['q3501'];
}

if(isset($_POST['q3901'])){
    $q3901= $_POST['q3901'];
}

if(isset($_POST['q0302'])){
    $q0302= $_POST['q0302'];
}

if(isset($_POST['q0702'])){
    $q0702= $_POST['q0702'];
}

if(isset($_POST['q1102'])){
    $q1102= $_POST['q1102'];
}

if(isset($_POST['q1502'])){
    $q1502= $_POST['q1502'];
}

if(isset($_POST['q1902'])){
    $q1902= $_POST['q1902'];
}
 
if(isset($_POST['q2302'])){
    $q2302= $_POST['q2302'];
}

if(isset($_POST['q2702'])){
    $q2702= $_POST['q2702'];
}

if(isset($_POST['q3102'])){
    $q3102= $_POST['q3102'];
}

  
if(isset($_POST['q3502'])){
    $q3502= $_POST['q3502'];
}

if(isset($_POST['q3902'])){
    $q3902= $_POST['q3902'];
}

if(isset($_POST['q0401'])){
    $q0401= $_POST['q0401'];
}

if(isset($_POST['q0801'])){
    $q0801= $_POST['q0801'];
}

if(isset($_POST['q1201'])){
    $q1201= $_POST['q1201'];
}

if(isset($_POST['q1601'])){
    $q1601= $_POST['q1601'];
}

if(isset($_POST['q2001'])){
    $q2001= $_POST['q2001'];
}

if(isset($_POST['q2401'])){
    $q2401= $_POST['q2401'];
}

if(isset($_POST['q2701'])){
    $q2701= $_POST['q2701'];
}

if(isset($_POST['q2801'])){
    $q2801= $_POST['q2801'];
}

if(isset($_POST['q3201'])){
    $q3201= $_POST['q3201'];
}

if(isset($_POST['q3601'])){
    $q3601= $_POST['q3601'];
}

if(isset($_POST['q4001'])){
    $q4001= $_POST['q4001'];
}

if(isset($_POST['q0402'])){
    $q0402= $_POST['q0402'];
}

if(isset($_POST['q0802'])){
    $q0802= $_POST['q0802'];
}

if(isset($_POST['q1202'])){
    $q1202= $_POST['q1202'];
}

if(isset($_POST['q1602'])){
    $q1602= $_POST['q1602'];
}

if(isset($_POST['q2002'])){
    $q2002= $_POST['q2002'];
}

if(isset($_POST['q2402'])){
    $q2402= $_POST['q2402'];
}

if(isset($_POST['q2802'])){
    $q2802= $_POST['q2802'];
}

if(isset($_POST['q2802'])){
    $q2802= $_POST['q2802'];
}

if(isset($_POST['q3202'])){
    $q3202= $_POST['q3202'];
}

if(isset($_POST['q3602'])){
    $q3602= $_POST['q3602'];
}


if(isset($_POST['q4002'])){
    $q4002= $_POST['q4002'];
}

?>